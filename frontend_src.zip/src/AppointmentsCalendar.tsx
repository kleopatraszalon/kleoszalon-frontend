// src/AppointmentsCalendar.tsx
// Csak továbbadjuk a pages-es komponenst.

import AppointmentsCalendarPage from "./pages/AppointmentsCalendar";

export default AppointmentsCalendarPage;
