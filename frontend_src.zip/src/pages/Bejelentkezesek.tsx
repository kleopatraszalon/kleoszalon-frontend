// src/pages/Bejelentkezesek.tsx
import React from "react";

const Bejelentkezesek = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Bejelentkezések modul</h1>
      <p>Itt lesznek az online és személyes bejelentkezések kezelése.</p>
    </div>
  );
};

export default Bejelentkezesek;