import React from "react";

const Penzugy = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Pénzügy</h1>
      <p>Itt lesznek a pénztár, tranzakciók és számlázási funkciók.</p>
    </div>
  );
};

export default Penzugy;
export {};
