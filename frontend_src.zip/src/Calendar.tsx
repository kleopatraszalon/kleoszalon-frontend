// src/Calendar.tsx
// Csak továbbadjuk a pages-es naptár oldalt.

import CalendarPage from "./pages/Calendar";

export default CalendarPage;
