// NOTE: This file exists only because it was accidentally created in the repo
// (double-dot in the filename). Keeping it as a safe re-export prevents
// TypeScript build errors without duplicating types/logic.

export * from "./signageAdmin";
