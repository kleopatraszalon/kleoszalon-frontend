import React from "react";

const Logisztika = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Logisztika / Raktár</h1>
      <p>Itt lesznek a bevételezések, készletmozgások és beszerzések kezelése.</p>
    </div>
  );
};

export default Logisztika;
export {};
